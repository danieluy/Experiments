export default function () {
  return [
    {
      id: 1,
      name: 'Tyler',
      lastname: 'Durden',
      age: 30,
      description: 'Main character of The Fight Club movie',
      avatar: 'https://i.pinimg.com/736x/a3/b2/7d/a3b27d91923b4955bcc86e7ae87dfcd3--fight-club--tyler-durden.jpg'
    },
    {
      id: 1,
      name: 'Marla',
      lastname: 'Singer',
      age: 30,
      description: 'Main character of The Fight Club movie',
      avatar: 'https://i.pinimg.com/736x/6c/94/e7/6c94e70b01f1a6519c3d03783b51ff80--helena-bonham-carter-halloween-costume-ideas.jpg'
    }
  ]
}